function login() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    if (username === "guest" && password === "party2025") {
        window.location.href = "invite.html";
    } else {
        document.getElementById("error-message").innerText = "Invalid credentials!";
    }
}